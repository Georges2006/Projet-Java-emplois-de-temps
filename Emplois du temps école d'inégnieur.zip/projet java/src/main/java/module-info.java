module main {
    requires java.sql;
    requires javafx.controls;
    requires javafx.fxml;

    opens main to javafx.fxml, javafx.graphics;


    opens ui to javafx.fxml;
    exports ui;
    exports model;
    exports dao;
    opens model to javafx.base;

    requires org.apache.pdfbox;
}
