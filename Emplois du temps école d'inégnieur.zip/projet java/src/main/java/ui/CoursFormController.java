package ui;

import dao.CoursDAO;
import dao.SalleDAO;
import dao.UtilisateurDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import model.Cours;
import model.Enseignant;
import model.Etudiant;
import model.Salle;

import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.ResourceBundle;

public class CoursFormController implements Initializable {

    @FXML
    private TextField nomField;

    @FXML
    private ComboBox<String> typeComboBox;

    @FXML
    private TextField dureeField;

    @FXML
    private DatePicker datePicker;

    @FXML
    private TextField heureDebutField;

    @FXML
    private TextField heureFinField;

    @FXML
    private ComboBox<Salle> salleComboBox;

    @FXML
    private ComboBox<Enseignant> enseignantComboBox;

    @FXML
    private ListView<Etudiant> etudiantsListView;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private Cours cours;
    private boolean isModification = false;

    private CoursDAO coursDAO = new CoursDAO();
    private SalleDAO salleDAO = new SalleDAO();
    private UtilisateurDAO utilisateurDAO = new UtilisateurDAO();


    public CoursFormController() {
        this.cours = new Cours();
    }


    public void setCours(Cours cours) {
        this.cours = cours;
        this.isModification = true;


        if (nomField != null) {
            fillFieldsWithCours();
        }
    }

    private void fillFieldsWithCours() {
        nomField.setText(cours.getNom());
        typeComboBox.setValue(cours.getType());
        dureeField.setText(String.valueOf(cours.getDuree()));
        datePicker.setValue(cours.getDate());
        heureDebutField.setText(cours.getHeureDebut().toString());
        heureFinField.setText(cours.getHeureFin().toString());


        if (cours.getSalle() != null) {
            for (Salle salle : salleComboBox.getItems()) {
                if (salle.getId() == cours.getSalle().getId()) {
                    salleComboBox.setValue(salle);
                    break;
                }
            }
        }


        if (cours.getEnseignant() != null) {
            for (Enseignant enseignant : enseignantComboBox.getItems()) {
                if (enseignant.getId() == cours.getEnseignant().getId()) {
                    enseignantComboBox.setValue(enseignant);
                    break;
                }
            }
        }


        if (cours.getEtudiants() != null && !cours.getEtudiants().isEmpty()) {
            for (Etudiant etudiant : cours.getEtudiants()) {
                for (int i = 0; i < etudiantsListView.getItems().size(); i++) {
                    if (etudiantsListView.getItems().get(i).getId() == etudiant.getId()) {
                        etudiantsListView.getSelectionModel().select(i);
                        break;
                    }
                }
            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        ObservableList<String> types = FXCollections.observableArrayList("CM", "TD", "TP");
        typeComboBox.setItems(types);


        datePicker.setValue(LocalDate.now());


        List<Salle> salles = salleDAO.trouverTous();
        ObservableList<Salle> sallesList = FXCollections.observableArrayList(salles);
        salleComboBox.setItems(sallesList);


        salleComboBox.setCellFactory(param -> new ListCell<Salle>() {
            @Override
            protected void updateItem(Salle salle, boolean empty) {
                super.updateItem(salle, empty);

                if (empty || salle == null) {
                    setText(null);
                } else {
                    setText(salle.getNumero() + " (Capacité: " + salle.getCapacite() + ")");
                }
            }
        });

        salleComboBox.setButtonCell(new ListCell<Salle>() {
            @Override
            protected void updateItem(Salle salle, boolean empty) {
                super.updateItem(salle, empty);

                if (empty || salle == null) {
                    setText(null);
                } else {
                    setText(salle.getNumero() + " (Capacité: " + salle.getCapacite() + ")");
                }
            }
        });


        List<Enseignant> enseignants = utilisateurDAO.trouverTousEnseignants();
        ObservableList<Enseignant> enseignantsList = FXCollections.observableArrayList(enseignants);
        enseignantComboBox.setItems(enseignantsList);


        enseignantComboBox.setCellFactory(param -> new ListCell<Enseignant>() {
            @Override
            protected void updateItem(Enseignant enseignant, boolean empty) {
                super.updateItem(enseignant, empty);

                if (empty || enseignant == null) {
                    setText(null);
                } else {
                    setText(enseignant.getNom() + " " + enseignant.getPrenom());
                }
            }
        });

        enseignantComboBox.setButtonCell(new ListCell<Enseignant>() {
            @Override
            protected void updateItem(Enseignant enseignant, boolean empty) {
                super.updateItem(enseignant, empty);

                if (empty || enseignant == null) {
                    setText(null);
                } else {
                    setText(enseignant.getNom() + " " + enseignant.getPrenom());
                }
            }
        });


        List<Etudiant> etudiants = utilisateurDAO.trouverTousEtudiants();
        ObservableList<Etudiant> etudiantsList = FXCollections.observableArrayList(etudiants);
        etudiantsListView.setItems(etudiantsList);


        etudiantsListView.setCellFactory(param -> new ListCell<Etudiant>() {
            @Override
            protected void updateItem(Etudiant etudiant, boolean empty) {
                super.updateItem(etudiant, empty);

                if (empty || etudiant == null) {
                    setText(null);
                } else {
                    setText(etudiant.getNom() + " " + etudiant.getPrenom());
                }
            }
        });


        etudiantsListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);


        if (isModification) {
            fillFieldsWithCours();
        }
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (!validateFields()) {
            return;
        }


        String nom = nomField.getText();
        String type = typeComboBox.getValue();
        int duree = Integer.parseInt(dureeField.getText());
        LocalDate date = datePicker.getValue();
        LocalTime heureDebut = LocalTime.parse(heureDebutField.getText());
        LocalTime heureFin = LocalTime.parse(heureFinField.getText());
        Salle salle = salleComboBox.getValue();
        Enseignant enseignant = enseignantComboBox.getValue();
        List<Etudiant> etudiants = etudiantsListView.getSelectionModel().getSelectedItems();


        cours.setNom(nom);
        cours.setType(type);
        cours.setDuree(duree);
        cours.setDate(date);
        cours.setHeureDebut(heureDebut);
        cours.setHeureFin(heureFin);
        cours.setSalle(salle);
        cours.setEnseignant(enseignant);
        cours.setEtudiants(etudiants);

        boolean success;

        if (isModification) {
            success = coursDAO.modifier(cours);
        } else {
            success = coursDAO.ajouter(cours);
        }

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Succès", "Le cours a été " + (isModification ? "modifié" : "ajouté") + " avec succès.");
            closeStage();
        } else {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors de l'" + (isModification ? "modification" : "ajout") + " du cours.");
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeStage();
    }

    private boolean validateFields() {
        if (nomField.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champ vide", "Veuillez saisir le nom du cours.");
            return false;
        }

        if (typeComboBox.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Champ vide", "Veuillez sélectionner le type du cours.");
            return false;
        }

        if (dureeField.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champ vide", "Veuillez saisir la durée du cours.");
            return false;
        }

        try {
            int duree = Integer.parseInt(dureeField.getText());
            if (duree <= 0) {
                showAlert(Alert.AlertType.WARNING, "Valeur invalide", "La durée doit être un nombre positif.");
                return false;
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.WARNING, "Valeur invalide", "La durée doit être un nombre entier.");
            return false;
        }

        if (datePicker.getValue() == null) {
            showAlert(Alert.AlertType.WARNING, "Champ vide", "Veuillez sélectionner une date pour le cours.");
            return false;
        }

        if (heureDebutField.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champ vide", "Veuillez saisir l'heure de début du cours.");
            return false;
        }

        if (heureFinField.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champ vide", "Veuillez saisir l'heure de fin du cours.");
            return false;
        }

        try {
            LocalTime heureDebut = LocalTime.parse(heureDebutField.getText());
            LocalTime heureFin = LocalTime.parse(heureFinField.getText());

            if (heureFin.isBefore(heureDebut)) {
                showAlert(Alert.AlertType.WARNING, "Valeur invalide", "L'heure de fin doit être après l'heure de début.");
                return false;
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.WARNING, "Valeur invalide", "Les heures doivent être au format HH:MM.");
            return false;
        }

        return true;
    }

    private void closeStage() {
        Stage stage = (Stage) saveButton.getScene().getWindow();
        stage.close();
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
