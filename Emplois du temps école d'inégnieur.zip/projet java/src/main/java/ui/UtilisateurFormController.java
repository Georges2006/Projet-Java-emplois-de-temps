package ui;

import dao.UtilisateurDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Admin;
import model.Enseignant;
import model.Etudiant;
import model.Utilisateur;

import java.net.URL;
import java.util.ResourceBundle;

public class UtilisateurFormController implements Initializable {

    @FXML
    private TextField nomField;

    @FXML
    private TextField prenomField;

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private String type;
    private Utilisateur utilisateur;
    private boolean isModification = false;

    private UtilisateurDAO utilisateurDAO = new UtilisateurDAO();


    public UtilisateurFormController() {

        this.type = "etudiant";
        this.utilisateur = new Etudiant();
    }


    public void setType(String type) {
        this.type = type;

        switch (type) {
            case "admin":
                this.utilisateur = new Admin();
                break;
            case "enseignant":
                this.utilisateur = new Enseignant();
                break;
            case "etudiant":
                this.utilisateur = new Etudiant();
                break;
            default:
                throw new IllegalArgumentException("Type d'utilisateur inconnu: " + type);
        }
    }


    public void setUtilisateur(Utilisateur utilisateur, String type) {
        this.utilisateur = utilisateur;
        this.type = type;
        this.isModification = true;


        if (nomField != null) {
            fillFieldsWithUtilisateur();
        }
    }

    private void fillFieldsWithUtilisateur() {
        nomField.setText(utilisateur.getNom());
        prenomField.setText(utilisateur.getPrenom());
        emailField.setText(utilisateur.getEmail());
        passwordField.setText(utilisateur.getMdp());
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        if (isModification) {
            fillFieldsWithUtilisateur();
        }
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (!validateFields()) {
            return;
        }


        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String email = emailField.getText();
        String password = passwordField.getText();


        utilisateur.setNom(nom);
        utilisateur.setPrenom(prenom);
        utilisateur.setEmail(email);
        utilisateur.setMdp(password);

        boolean success;

        if (isModification) {
            success = utilisateurDAO.modifier(utilisateur);
        } else {
            success = utilisateurDAO.ajouter(utilisateur);
        }

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Succès", "L'utilisateur a été " + (isModification ? "modifié" : "ajouté") + " avec succès.");
            closeStage();
        } else {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors de l'" + (isModification ? "modification" : "ajout") + " de l'utilisateur.");
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeStage();
    }

    private boolean validateFields() {
        if (nomField.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champ vide", "Veuillez saisir le nom de l'utilisateur.");
            return false;
        }

        if (prenomField.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champ vide", "Veuillez saisir le prénom de l'utilisateur.");
            return false;
        }

        if (emailField.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champ vide", "Veuillez saisir l'email de l'utilisateur.");
            return false;
        }

        if (passwordField.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champ vide", "Veuillez saisir le mot de passe de l'utilisateur.");
            return false;
        }

        return true;
    }

    private void closeStage() {
        Stage stage = (Stage) saveButton.getScene().getWindow();
        stage.close();
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

