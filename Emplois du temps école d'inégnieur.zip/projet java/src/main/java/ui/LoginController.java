package ui;

import dao.UtilisateurDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Admin;
import model.Enseignant;
import model.Etudiant;
import model.Utilisateur;

import java.io.IOException;

public class LoginController {

    @FXML
    private TextField emailField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button loginButton;

    @FXML
    private Hyperlink forgotPasswordLink;

    private UtilisateurDAO utilisateurDAO = new UtilisateurDAO();

    @FXML
    private void initialize() {

    }

    @FXML
    private void handleLogin(ActionEvent event) {
        String email = emailField.getText().trim();
        String password = passwordField.getText();

        if (email.isEmpty() || password.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Erreur de connexion", "Veuillez remplir tous les champs.");
            return;
        }

        Utilisateur utilisateur = utilisateurDAO.authentifier(email, password);
        if (utilisateur == null) {
            showAlert(Alert.AlertType.ERROR, "Erreur de connexion", "Email ou mot de passe incorrect.");
            return;
        }

        try {
            FXMLLoader loader;
            Parent root;
            Stage stage = (Stage) loginButton.getScene().getWindow();

            if (utilisateur instanceof Admin) {

                loader = new FXMLLoader(getClass().getResource("/fxml/admin_dashboard.fxml"));
                root = loader.load();
                AdminDashboardController ctrl = loader.getController();
                ctrl.setAdmin((Admin) utilisateur);
                stage.setTitle("Dashboard Admin");

            } else if (utilisateur instanceof Enseignant) {

                loader = new FXMLLoader(getClass().getResource("/fxml/emploi_du_temps.fxml"));
                root = loader.load();
                EmploiDuTempsController ctrl = loader.getController();
                ctrl.setUtilisateur(utilisateur);
                stage.setTitle("Emploi du temps - Enseignant");

            } else if (utilisateur instanceof Etudiant) {

                loader = new FXMLLoader(getClass().getResource("/fxml/emploi_du_temps.fxml"));
                root = loader.load();
                EmploiDuTempsController ctrl = loader.getController();
                ctrl.setUtilisateur(utilisateur);
                stage.setTitle("Emploi du temps - Étudiant");

            } else {

                showAlert(Alert.AlertType.WARNING, "Type inconnu", "Type d'utilisateur non géré.");
                return;
            }

            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement de l'interface.");
        }
    }

    @FXML
    private void handleForgotPassword() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/forgot_password.fxml"));
            Parent root = loader.load();

            Stage forgotPasswordStage = new Stage();
            forgotPasswordStage.setTitle("Mot de passe oublié");
            forgotPasswordStage.initModality(Modality.APPLICATION_MODAL);
            forgotPasswordStage.setScene(new Scene(root));
            forgotPasswordStage.showAndWait();

        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement de la fenêtre de mot de passe oublié.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
