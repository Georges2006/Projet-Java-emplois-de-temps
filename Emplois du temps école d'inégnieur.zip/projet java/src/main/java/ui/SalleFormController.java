package ui;

import dao.SalleDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Salle;

import java.net.URL;
import java.util.ResourceBundle;

public class SalleFormController implements Initializable {

    @FXML
    private TextField numeroField;

    @FXML
    private TextField capaciteField;

    @FXML
    private TextArea equipementTextArea;

    @FXML
    private Button saveButton;

    @FXML
    private Button cancelButton;

    private Salle salle;
    private boolean isModification = false;

    private SalleDAO salleDAO = new SalleDAO();


    public SalleFormController() {
        this.salle = new Salle();
    }


    public void setSalle(Salle salle) {
        this.salle = salle;
        this.isModification = true;


        if (numeroField != null) {
            fillFieldsWithSalle();
        }
    }

    private void fillFieldsWithSalle() {
        numeroField.setText(salle.getNumero());
        capaciteField.setText(String.valueOf(salle.getCapacite()));
        equipementTextArea.setText(salle.getEquipement());
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        if (isModification) {
            fillFieldsWithSalle();
        }
    }

    @FXML
    private void handleSave(ActionEvent event) {
        if (!validateFields()) {
            return;
        }


        String numero = numeroField.getText();
        int capacite = Integer.parseInt(capaciteField.getText());
        String equipement = equipementTextArea.getText();


        salle.setNumero(numero);
        salle.setCapacite(capacite);
        salle.setEquipement(equipement);

        boolean success;

        if (isModification) {
            success = salleDAO.modifier(salle);
        } else {
            success = salleDAO.ajouter(salle);
        }

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Succès", "La salle a été " + (isModification ? "modifiée" : "ajoutée") + " avec succès.");
            closeStage();
        } else {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors de l'" + (isModification ? "modification" : "ajout") + " de la salle.");
        }
    }

    @FXML
    private void handleCancel(ActionEvent event) {
        closeStage();
    }

    private boolean validateFields() {
        if (numeroField.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champ vide", "Veuillez saisir le numéro de la salle.");
            return false;
        }

        if (capaciteField.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champ vide", "Veuillez saisir la capacité de la salle.");
            return false;
        }

        try {
            int capacite = Integer.parseInt(capaciteField.getText());
            if (capacite <= 0) {
                showAlert(Alert.AlertType.WARNING, "Valeur invalide", "La capacité doit être un nombre positif.");
                return false;
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.WARNING, "Valeur invalide", "La capacité doit être un nombre entier.");
            return false;
        }

        return true;
    }

    private void closeStage() {
        Stage stage = (Stage) saveButton.getScene().getWindow();
        stage.close();
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

