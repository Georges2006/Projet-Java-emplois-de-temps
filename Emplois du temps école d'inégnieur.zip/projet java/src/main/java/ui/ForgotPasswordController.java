package ui;

import dao.NotificationDAO;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Notification;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ForgotPasswordController {

    @FXML
    private TextField emailField;

    @FXML
    private TextField nomField;

    @FXML
    private TextField prenomField;

    @FXML
    private Button cancelButton;

    @FXML
    private Button submitButton;

    private NotificationDAO notificationDAO = new NotificationDAO();

    @FXML
    private void handleCancel(ActionEvent event) {

        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void handleSubmit(ActionEvent event) {

        if (emailField.getText().isEmpty() || nomField.getText().isEmpty() || prenomField.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champs incomplets", "Veuillez remplir tous les champs.");
            return;
        }


        String email = emailField.getText().trim();
        String nom = nomField.getText().trim();
        String prenom = prenomField.getText().trim();

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        String dateStr = now.format(formatter);

        String contenu = "Demande de réinitialisation de mot de passe\n" +
                "Date: " + dateStr + "\n" +
                "Email: " + email + "\n" +
                "Nom: " + nom + "\n" +
                "Prénom: " + prenom;


        Notification notification = new Notification(0, contenu, "admin");
        boolean success = notificationDAO.ajouter(notification);

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Demande envoyée",
                    "Votre demande de réinitialisation de mot de passe a été envoyée à l'administrateur.");


            Stage stage = (Stage) submitButton.getScene().getWindow();
            stage.close();
        } else {
            showAlert(Alert.AlertType.ERROR, "Erreur",
                    "Une erreur est survenue lors de l'envoi de votre demande. Veuillez réessayer plus tard.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
