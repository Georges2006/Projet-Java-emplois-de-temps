package ui;

import dao.CoursDAO;
import dao.NotificationDAO;
import dao.SalleDAO;
import dao.UtilisateurDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class AdminDashboardController implements Initializable {

    @FXML
    private Label welcomeLabel;

    @FXML
    private TabPane tabPane;


    @FXML
    private TableView<Cours> coursTable;

    @FXML
    private TableColumn<Cours, String> coursNomColumn;

    @FXML
    private TableColumn<Cours, String> coursTypeColumn;

    @FXML
    private TableColumn<Cours, Integer> coursDureeColumn;

    @FXML
    private TableColumn<Cours, String> coursHeureDebutColumn;

    @FXML
    private TableColumn<Cours, String> coursHeureFinColumn;

    @FXML
    private TableColumn<Cours, String> coursSalleColumn;

    @FXML
    private TableColumn<Cours, String> coursEnseignantColumn;


    @FXML
    private TableView<Enseignant> enseignantsTable;

    @FXML
    private TableColumn<Enseignant, String> enseignantNomColumn;

    @FXML
    private TableColumn<Enseignant, String> enseignantPrenomColumn;

    @FXML
    private TableColumn<Enseignant, String> enseignantEmailColumn;


    @FXML
    private TableView<Etudiant> etudiantsTable;

    @FXML
    private TableColumn<Etudiant, String> etudiantNomColumn;

    @FXML
    private TableColumn<Etudiant, String> etudiantPrenomColumn;

    @FXML
    private TableColumn<Etudiant, String> etudiantEmailColumn;


    @FXML
    private TableView<Salle> sallesTable;

    @FXML
    private TableColumn<Salle, String> salleNumeroColumn;

    @FXML
    private TableColumn<Salle, Integer> salleCapaciteColumn;

    @FXML
    private TableColumn<Salle, String> salleEquipementColumn;


    @FXML
    private VBox notificationsContainer;

    private Admin admin;
    private CoursDAO coursDAO = new CoursDAO();
    private UtilisateurDAO utilisateurDAO = new UtilisateurDAO();
    private SalleDAO salleDAO = new SalleDAO();
    private NotificationDAO notificationDAO = new NotificationDAO();

    private List<Notification> notifications;
    private Notification selectedNotification;

    @Override
    public void initialize(URL url, ResourceBundle rb) {



        coursNomColumn.setCellValueFactory(new PropertyValueFactory<>("nom"));
        coursTypeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        coursDureeColumn.setCellValueFactory(new PropertyValueFactory<>("duree"));
        coursHeureDebutColumn.setCellValueFactory(new PropertyValueFactory<>("heureDebut"));
        coursHeureFinColumn.setCellValueFactory(new PropertyValueFactory<>("heureFin"));

        coursSalleColumn.setCellValueFactory(cellData -> {
            Salle salle = cellData.getValue().getSalle();
            return javafx.beans.binding.Bindings.createStringBinding(() ->
                    salle != null ? salle.getNumero() : "Non assignée");
        });

        coursEnseignantColumn.setCellValueFactory(cellData -> {
            Enseignant enseignant = cellData.getValue().getEnseignant();
            return javafx.beans.binding.Bindings.createStringBinding(() ->
                    enseignant != null ? enseignant.getNom() + " " + enseignant.getPrenom() : "Non assigné");
        });


        enseignantNomColumn.setCellValueFactory(new PropertyValueFactory<>("nom"));
        enseignantPrenomColumn.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        enseignantEmailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));


        etudiantNomColumn.setCellValueFactory(new PropertyValueFactory<>("nom"));
        etudiantPrenomColumn.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        etudiantEmailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));


        salleNumeroColumn.setCellValueFactory(new PropertyValueFactory<>("numero"));
        salleCapaciteColumn.setCellValueFactory(new PropertyValueFactory<>("capacite"));
        salleEquipementColumn.setCellValueFactory(new PropertyValueFactory<>("equipement"));
    }

    public void setAdmin(Admin admin) {
        this.admin = admin;
        if (welcomeLabel != null) {
            welcomeLabel.setText("Bienvenue, " + admin.getPrenom() + " " + admin.getNom());
        }
        chargerDonnees();
    }

    public void chargerDonnees() {
        try {

            List<Cours> cours = coursDAO.trouverTous();
            ObservableList<Cours> coursList = FXCollections.observableArrayList(cours);
            coursTable.setItems(coursList);


            List<Enseignant> enseignants = utilisateurDAO.trouverTousEnseignants();
            ObservableList<Enseignant> enseignantsList = FXCollections.observableArrayList(enseignants);
            enseignantsTable.setItems(enseignantsList);


            List<Etudiant> etudiants = utilisateurDAO.trouverTousEtudiants();
            ObservableList<Etudiant> etudiantsList = FXCollections.observableArrayList(etudiants);
            etudiantsTable.setItems(etudiantsList);


            List<Salle> salles = salleDAO.trouverTous();
            ObservableList<Salle> sallesList = FXCollections.observableArrayList(salles);
            sallesTable.setItems(sallesList);


            chargerNotifications();

        } catch (Exception e) {
            System.err.println("Erreur lors du chargement des données: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void chargerNotifications() {

        notificationsContainer.getChildren().clear();


        notifications = notificationDAO.trouverParDestinataire("admin");

        if (notifications.isEmpty()) {
            Label emptyLabel = new Label("Aucune notification");
            emptyLabel.setStyle("-fx-font-style: italic; -fx-text-fill: -fx-primary-medium;");
            notificationsContainer.getChildren().add(emptyLabel);
        } else {

            for (Notification notification : notifications) {
                VBox notificationCard = createNotificationCard(notification);
                notificationsContainer.getChildren().add(notificationCard);
            }
        }
    }

    private VBox createNotificationCard(Notification notification) {
        VBox card = new VBox(5);
        card.getStyleClass().add("notification-card");
        card.setPadding(new Insets(10));


        String contenu = notification.getContenu();
        String[] lignes = contenu.split("\n");


        Label titleLabel = new Label(lignes[0]);
        titleLabel.getStyleClass().add("notification-title");


        VBox contentBox = new VBox(2);
        for (int i = 1; i < lignes.length; i++) {
            Label lineLabel = new Label(lignes[i]);
            lineLabel.getStyleClass().add("notification-content");
            contentBox.getChildren().add(lineLabel);
        }


        HBox buttonsBox = new HBox(10);
        buttonsBox.setPadding(new Insets(5, 0, 0, 0));

        Button resetPasswordButton = new Button("Réinitialiser MDP");
        resetPasswordButton.getStyleClass().add("primary-button");
        resetPasswordButton.setOnAction(e -> handleResetPassword(notification));

        Button deleteButton = new Button("Supprimer");
        deleteButton.getStyleClass().add("cancel-button");
        deleteButton.setOnAction(e -> handleDeleteNotification(notification));

        buttonsBox.getChildren().addAll(resetPasswordButton, deleteButton);


        card.setOnMouseClicked(e -> {
            selectedNotification = notification;

            notificationsContainer.getChildren().forEach(node -> {
                if (node instanceof VBox) {
                    if (node == card) {
                        node.setStyle("-fx-border-color: -fx-primary-light; -fx-border-width: 2px;");
                    } else {
                        node.setStyle("-fx-border-color: -fx-primary-light; -fx-border-width: 1px;");
                    }
                }
            });
        });

        card.getChildren().addAll(titleLabel, contentBox, buttonsBox);
        return card;
    }

    private void handleResetPassword(Notification notification) {

        String contenu = notification.getContenu();
        String email = "";

        for (String ligne : contenu.split("\n")) {
            if (ligne.startsWith("Email:")) {
                email = ligne.substring("Email:".length()).trim();
                break;
            }
        }

        if (email.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Information manquante", "Impossible de trouver l'email dans la notification.");
            return;
        }


        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Confirmation");
        confirmAlert.setHeaderText("Réinitialisation du mot de passe");
        confirmAlert.setContentText("Voulez-vous réinitialiser le mot de passe pour l'utilisateur avec l'email: " + email + "?");

        Optional<ButtonType> result = confirmAlert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {

            Utilisateur utilisateur = utilisateurDAO.trouverParEmail(email);

            if (utilisateur == null) {
                showAlert(Alert.AlertType.WARNING, "Utilisateur introuvable", "Aucun utilisateur trouvé avec l'email: " + email);
                return;
            }


            String nouveauMdp = "password";
            utilisateur.setMdp(nouveauMdp);

            boolean success = utilisateurDAO.modifier(utilisateur);

            if (success) {
                showAlert(Alert.AlertType.INFORMATION, "Succès", "Le mot de passe a été réinitialisé à: " + nouveauMdp);


                notificationDAO.supprimer(notification.getId());
                chargerNotifications();
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors de la réinitialisation du mot de passe.");
            }
        }
    }

    private void handleDeleteNotification(Notification notification) {

        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Confirmation");
        confirmAlert.setHeaderText("Suppression de la notification");
        confirmAlert.setContentText("Voulez-vous supprimer cette notification?");

        Optional<ButtonType> result = confirmAlert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            boolean success = notificationDAO.supprimer(notification.getId());

            if (success) {
                chargerNotifications();
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors de la suppression de la notification.");
            }
        }
    }

    @FXML
    private void handleRafraichirNotifications(ActionEvent event) {
        chargerNotifications();
    }

    @FXML
    private void handleSupprimerNotification(ActionEvent event) {
        if (selectedNotification == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner une notification à supprimer.");
            return;
        }

        handleDeleteNotification(selectedNotification);
    }

    @FXML
    private void handleAjouterCours(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/cours_form.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Ajouter un cours");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();


            chargerDonnees();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement du formulaire.");
        }
    }

    @FXML
    private void handleModifierCours(ActionEvent event) {
        Cours coursSelectionne = coursTable.getSelectionModel().getSelectedItem();

        if (coursSelectionne == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un cours à modifier.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/cours_form.fxml"));
            Parent root = loader.load();

            CoursFormController controller = loader.getController();
            controller.setCours(coursSelectionne);

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Modifier un cours");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();


            chargerDonnees();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement du formulaire.");
        }
    }

    @FXML
    private void handleSupprimerCours(ActionEvent event) {
        Cours coursSelectionne = coursTable.getSelectionModel().getSelectedItem();

        if (coursSelectionne == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un cours à supprimer.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de suppression");
        alert.setHeaderText("Supprimer le cours");
        alert.setContentText("Êtes-vous sûr de vouloir supprimer le cours " + coursSelectionne.getNom() + "?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            boolean success = coursDAO.supprimer(coursSelectionne.getId());

            if (success) {
                chargerDonnees();
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors de la suppression du cours.");
            }
        }
    }

    @FXML
    private void handleAjouterEnseignant(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/utilisateur_form.fxml"));
            Parent root = loader.load();

            UtilisateurFormController controller = loader.getController();
            controller.setType("enseignant");

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Ajouter un enseignant");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();


            chargerDonnees();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement du formulaire.");
        }
    }

    @FXML
    private void handleModifierEnseignant(ActionEvent event) {
        Enseignant enseignantSelectionne = enseignantsTable.getSelectionModel().getSelectedItem();

        if (enseignantSelectionne == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un enseignant à modifier.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/utilisateur_form.fxml"));
            Parent root = loader.load();

            UtilisateurFormController controller = loader.getController();
            controller.setUtilisateur(enseignantSelectionne, "enseignant");

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Modifier un enseignant");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();


            chargerDonnees();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement du formulaire.");
        }
    }

    @FXML
    private void handleSupprimerEnseignant(ActionEvent event) {
        Enseignant enseignantSelectionne = enseignantsTable.getSelectionModel().getSelectedItem();

        if (enseignantSelectionne == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un enseignant à supprimer.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de suppression");
        alert.setHeaderText("Supprimer l'enseignant");
        alert.setContentText("Êtes-vous sûr de vouloir supprimer l'enseignant " + enseignantSelectionne.getNom() + " " + enseignantSelectionne.getPrenom() + "?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            boolean success = utilisateurDAO.supprimer(enseignantSelectionne.getId());

            if (success) {
                chargerDonnees();
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors de la suppression de l'enseignant.");
            }
        }
    }

    @FXML
    private void handleAjouterEtudiant(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/utilisateur_form.fxml"));
            Parent root = loader.load();

            UtilisateurFormController controller = loader.getController();
            controller.setType("etudiant");

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Ajouter un étudiant");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();


            chargerDonnees();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement du formulaire.");
        }
    }

    @FXML
    private void handleModifierEtudiant(ActionEvent event) {
        Etudiant etudiantSelectionne = etudiantsTable.getSelectionModel().getSelectedItem();

        if (etudiantSelectionne == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un étudiant à modifier.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/utilisateur_form.fxml"));
            Parent root = loader.load();

            UtilisateurFormController controller = loader.getController();
            controller.setUtilisateur(etudiantSelectionne, "etudiant");

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Modifier un étudiant");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();


            chargerDonnees();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement du formulaire.");
        }
    }

    @FXML
    private void handleSupprimerEtudiant(ActionEvent event) {
        Etudiant etudiantSelectionne = etudiantsTable.getSelectionModel().getSelectedItem();

        if (etudiantSelectionne == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un étudiant à supprimer.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de suppression");
        alert.setHeaderText("Supprimer l'étudiant");
        alert.setContentText("Êtes-vous sûr de vouloir supprimer l'étudiant " + etudiantSelectionne.getNom() + " " + etudiantSelectionne.getPrenom() + "?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            boolean success = utilisateurDAO.supprimer(etudiantSelectionne.getId());

            if (success) {
                chargerDonnees();
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors de la suppression de l'étudiant.");
            }
        }
    }

    @FXML
    private void handleAjouterSalle(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/salle_form.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Ajouter une salle");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();


            chargerDonnees();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement du formulaire.");
        }
    }

    @FXML
    private void handleModifierSalle(ActionEvent event) {
        Salle salleSelectionnee = sallesTable.getSelectionModel().getSelectedItem();

        if (salleSelectionnee == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner une salle à modifier.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/salle_form.fxml"));
            Parent root = loader.load();

            SalleFormController controller = loader.getController();
            controller.setSalle(salleSelectionnee);

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Modifier une salle");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();


            chargerDonnees();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement du formulaire.");
        }
    }

    @FXML
    private void handleSupprimerSalle(ActionEvent event) {
        Salle salleSelectionnee = sallesTable.getSelectionModel().getSelectedItem();

        if (salleSelectionnee == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner une salle à supprimer.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de suppression");
        alert.setHeaderText("Supprimer la salle");
        alert.setContentText("Êtes-vous sûr de vouloir supprimer la salle " + salleSelectionnee.getNumero() + "?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            boolean success = salleDAO.supprimer(salleSelectionnee.getId());

            if (success) {
                chargerDonnees();
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors de la suppression de la salle.");
            }
        }
    }

    @FXML
    private void handleDeconnexion(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) welcomeLabel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Connexion");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement de la page de connexion.");
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
