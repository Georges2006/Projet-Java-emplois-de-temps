package ui;

import dao.CoursDAO;
import dao.NotificationDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Cours;
import model.Etudiant;
import model.Notification;
import model.Salle;

import java.io.IOException;
import java.net.URL;
import java.time.LocalTime;
import java.util.List;
import java.util.ResourceBundle;

public class EtudiantDashboardController implements Initializable {

    @FXML
    private Label welcomeLabel;

    @FXML
    private TabPane tabPane;


    @FXML
    private TableView<Cours> coursTable;

    @FXML
    private TableColumn<Cours, String> coursNomColumn;

    @FXML
    private TableColumn<Cours, String> coursTypeColumn;

    @FXML
    private TableColumn<Cours, Integer> coursDureeColumn;

    @FXML
    private TableColumn<Cours, LocalTime> coursHeureDebutColumn;

    @FXML
    private TableColumn<Cours, LocalTime> coursHeureFinColumn;

    @FXML
    private TableColumn<Cours, String> coursSalleColumn;

    @FXML
    private TableColumn<Cours, String> coursEnseignantColumn;


    @FXML
    private ListView<Notification> notificationsListView;

    private Etudiant etudiant;
    private CoursDAO coursDAO = new CoursDAO();
    private NotificationDAO notificationDAO = new NotificationDAO();

    public void setEtudiant(Etudiant etudiant) {
        this.etudiant = etudiant;
        if (welcomeLabel != null) {
            welcomeLabel.setText("Bienvenue, " + etudiant.getPrenom() + " " + etudiant.getNom());
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {



        coursNomColumn.setCellValueFactory(new PropertyValueFactory<>("nom"));
        coursTypeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        coursDureeColumn.setCellValueFactory(new PropertyValueFactory<>("duree"));
        coursHeureDebutColumn.setCellValueFactory(new PropertyValueFactory<>("heureDebut"));
        coursHeureFinColumn.setCellValueFactory(new PropertyValueFactory<>("heureFin"));

        coursSalleColumn.setCellValueFactory(cellData -> {
            Salle salle = cellData.getValue().getSalle();
            return javafx.beans.binding.Bindings.createStringBinding(() ->
                    salle != null ? salle.getNumero() : "Non assignée");
        });

        coursEnseignantColumn.setCellValueFactory(cellData -> {
            model.Enseignant enseignant = cellData.getValue().getEnseignant();
            return javafx.beans.binding.Bindings.createStringBinding(() ->
                    enseignant != null ? enseignant.getNom() + " " + enseignant.getPrenom() : "Non assigné");
        });


        notificationsListView.setCellFactory(param -> new ListCell<Notification>() {
            @Override
            protected void updateItem(Notification notification, boolean empty) {
                super.updateItem(notification, empty);

                if (empty || notification == null) {
                    setText(null);
                } else {
                    setText(notification.getContenu());
                }
            }
        });
    }

    public void chargerDonnees() {
        try {
            if (etudiant != null) {

                List<Cours> cours = coursDAO.trouverParEtudiantId(etudiant.getId());
                ObservableList<Cours> coursList = FXCollections.observableArrayList(cours);
                coursTable.setItems(coursList);


                List<Notification> notifications = notificationDAO.trouverParDestinataire(etudiant.getEmail());
                ObservableList<Notification> notificationsList = FXCollections.observableArrayList(notifications);
                notificationsListView.setItems(notificationsList);
            }
        } catch (Exception e) {
            System.err.println("Erreur lors du chargement des données: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleVoirDetailsCours(ActionEvent event) {
        Cours coursSelectionne = coursTable.getSelectionModel().getSelectedItem();

        if (coursSelectionne == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un cours pour voir les détails.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Détails du cours");
        alert.setHeaderText(coursSelectionne.getNom());
        alert.setContentText(coursSelectionne.getInfos());
        alert.showAndWait();
    }

    @FXML
    private void handleVoirDetailsSalle(ActionEvent event) {
        Cours coursSelectionne = coursTable.getSelectionModel().getSelectedItem();

        if (coursSelectionne == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un cours pour voir les détails de la salle.");
            return;
        }

        Salle salle = coursSelectionne.getSalle();

        if (salle == null) {
            showAlert(Alert.AlertType.WARNING, "Pas de salle", "Ce cours n'a pas de salle assignée.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Détails de la salle");
        alert.setHeaderText("Salle " + salle.getNumero());
        alert.setContentText("Capacité: " + salle.getCapacite() + " personnes\n" +
                "Équipement: " + salle.getEquipement());
        alert.showAndWait();
    }

    @FXML
    private void handleDeconnexion(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) welcomeLabel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Connexion");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement de la page de connexion.");
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
