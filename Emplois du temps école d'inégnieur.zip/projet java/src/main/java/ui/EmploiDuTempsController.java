package ui;

import dao.CoursDAO;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Cours;
import model.Enseignant;
import model.Etudiant;
import model.Utilisateur;
import model.Admin;
import util.PDFExporter;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.time.temporal.WeekFields;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class EmploiDuTempsController implements Initializable {

    @FXML
    private Label titleLabel;

    @FXML
    private DatePicker datePicker;

    @FXML
    private ComboBox<String> viewComboBox;

    @FXML
    private TableView<Cours> coursTable;

    @FXML
    private TableColumn<Cours, String> coursNomColumn;

    @FXML
    private TableColumn<Cours, String> coursTypeColumn;

    @FXML
    private TableColumn<Cours, String> coursDateColumn;

    @FXML
    private TableColumn<Cours, String> coursDebutColumn;

    @FXML
    private TableColumn<Cours, String> coursFinColumn;

    @FXML
    private TableColumn<Cours, String> coursEnseignantColumn;

    @FXML
    private TableColumn<Cours, String> coursSalleColumn;

    @FXML
    private VBox detailsContainer;

    @FXML
    private Label detailsTitleLabel;

    @FXML
    private Label detailsNomLabel;

    @FXML
    private Label detailsTypeLabel;

    @FXML
    private Label detailsDateLabel;

    @FXML
    private Label detailsHoraireLabel;

    @FXML
    private Label detailsEnseignantLabel;

    @FXML
    private Label detailsSalleLabel;

    @FXML
    private Label detailsSalleNumeroLabel;

    @FXML
    private Label detailsSalleCapaciteLabel;

    @FXML
    private Label detailsSalleEquipementLabel;

    @FXML
    private Label detailsSalleDisponibiliteLabel;

    @FXML
    private Button detailsModifierButton;


    @FXML
    private GridPane weekViewGrid;

    @FXML
    private GridPane monthViewGrid;

    private CoursDAO coursDAO = new CoursDAO();
    private Utilisateur utilisateur;
    private String currentView = "Jour";

    public void setUtilisateur(Utilisateur utilisateur) {
        this.utilisateur = utilisateur;
        titleLabel.setText("Emploi du temps - " + utilisateur.getPrenom() + " " + utilisateur.getNom());
        chargerDonnees();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        datePicker.setValue(LocalDate.now());


        ObservableList<String> views = FXCollections.observableArrayList("Jour", "Semaine", "Mois");
        viewComboBox.setItems(views);
        viewComboBox.setValue("Jour");


        coursNomColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNom()));
        coursTypeColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getType()));
        coursDateColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))));
        coursDebutColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getHeureDebut().toString()));
        coursFinColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getHeureFin().toString()));

        coursEnseignantColumn.setCellValueFactory(cellData -> {
            Enseignant enseignant = cellData.getValue().getEnseignant();
            return new SimpleStringProperty(enseignant != null ? enseignant.getNom() + " " + enseignant.getPrenom() : "Non assigné");
        });

        coursSalleColumn.setCellValueFactory(cellData -> {
            model.Salle salle = cellData.getValue().getSalle();
            return new SimpleStringProperty(salle != null ? salle.getNumero() : "Non assignée");
        });


        coursTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                afficherDetailsCours(newSelection);
            }
        });


        datePicker.valueProperty().addListener((obs, oldDate, newDate) -> {
            if (newDate != null) {
                chargerDonnees();
            }
        });


        viewComboBox.valueProperty().addListener((obs, oldView, newView) -> {
            if (newView != null) {
                currentView = newView;
                chargerDonnees();
            }
        });
    }

    public void chargerDonnees() {
        if (utilisateur == null) {
            return;
        }

        List<Cours> cours = null;

        switch (currentView) {
            case "Jour":
                cours = chargerCoursJour();
                break;
            case "Semaine":
                cours = chargerCoursSemaine();
                break;
            case "Mois":
                cours = chargerCoursMois();
                break;
        }

        if (cours != null) {
            ObservableList<Cours> coursList = FXCollections.observableArrayList(cours);
            coursTable.setItems(coursList);


            if (!coursList.isEmpty()) {
                coursTable.getSelectionModel().select(0);
                afficherDetailsCours(coursList.get(0));
            } else {

                effacerDetailsCours();
            }
        }
    }

    private List<Cours> chargerCoursJour() {
        LocalDate date = datePicker.getValue();

        if (utilisateur instanceof Enseignant) {

            return coursDAO.trouverParEnseignantId(utilisateur.getId()).stream()
                    .filter(c -> c.getDate().equals(date))
                    .collect(Collectors.toList());
        } else if (utilisateur instanceof Etudiant) {

            return coursDAO.trouverParEtudiantId(utilisateur.getId()).stream()
                    .filter(c -> c.getDate().equals(date))
                    .collect(Collectors.toList());
        } else {

            return coursDAO.trouverParDate(date);
        }
    }

    private List<Cours> chargerCoursSemaine() {
        LocalDate date = datePicker.getValue();
        LocalDate debutSemaine = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate finSemaine = debutSemaine.plusDays(6);

        if (utilisateur instanceof Enseignant) {

            return coursDAO.trouverParEnseignantId(utilisateur.getId()).stream()
                    .filter(c -> !c.getDate().isBefore(debutSemaine) && !c.getDate().isAfter(finSemaine))
                    .collect(Collectors.toList());
        } else if (utilisateur instanceof Etudiant) {

            return coursDAO.trouverParEtudiantId(utilisateur.getId()).stream()
                    .filter(c -> !c.getDate().isBefore(debutSemaine) && !c.getDate().isAfter(finSemaine))
                    .collect(Collectors.toList());
        } else {

            return coursDAO.trouverParSemaine(debutSemaine, finSemaine);
        }
    }

    private List<Cours> chargerCoursMois() {
        LocalDate date = datePicker.getValue();
        int mois = date.getMonthValue();
        int annee = date.getYear();

        if (utilisateur instanceof Enseignant) {

            return coursDAO.trouverParEnseignantId(utilisateur.getId()).stream()
                    .filter(c -> c.getDate().getMonthValue() == mois && c.getDate().getYear() == annee)
                    .collect(Collectors.toList());
        } else if (utilisateur instanceof Etudiant) {

            return coursDAO.trouverParEtudiantId(utilisateur.getId()).stream()
                    .filter(c -> c.getDate().getMonthValue() == mois && c.getDate().getYear() == annee)
                    .collect(Collectors.toList());
        } else {

            return coursDAO.trouverParMois(mois, annee);
        }
    }

    private void afficherDetailsCours(Cours cours) {
        detailsContainer.setVisible(true);
        detailsTitleLabel.setText("Détails du cours");
        detailsNomLabel.setText("Nom: " + cours.getNom());
        detailsTypeLabel.setText("Type: " + cours.getType());
        detailsDateLabel.setText("Date: " + cours.getDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        detailsHoraireLabel.setText("Horaire: " + cours.getHeureDebut() + " - " + cours.getHeureFin());

        if (cours.getEnseignant() != null) {
            detailsEnseignantLabel.setText("Enseignant: " + cours.getEnseignant().getNom() + " " + cours.getEnseignant().getPrenom());
        } else {
            detailsEnseignantLabel.setText("Enseignant: Non assigné");
        }


        if (cours.getSalle() != null) {
            model.Salle salle = cours.getSalle();
            detailsSalleNumeroLabel.setText("Numéro: " + salle.getNumero());
            detailsSalleCapaciteLabel.setText("Capacité: " + salle.getCapacite() + " personnes");
            detailsSalleEquipementLabel.setText("Équipement: " + (salle.getEquipement() != null && !salle.getEquipement().isEmpty() ? salle.getEquipement() : "Aucun"));


            boolean estDisponible = verifierDisponibiliteSalle(salle.getId(), cours.getDate(), cours.getHeureDebut(), cours.getHeureFin(), cours.getId());
            detailsSalleDisponibiliteLabel.setText("Disponibilité: " + (estDisponible ? "Disponible" : "Occupée par d'autres cours"));
        } else {
            detailsSalleNumeroLabel.setText("Numéro: Non assignée");
            detailsSalleCapaciteLabel.setText("Capacité: -");
            detailsSalleEquipementLabel.setText("Équipement: -");
            detailsSalleDisponibiliteLabel.setText("Disponibilité: -");
        }


        boolean estAdmin = utilisateur instanceof Admin;
        detailsModifierButton.setVisible(estAdmin);
        detailsModifierButton.setManaged(estAdmin);

    }

    private boolean verifierDisponibiliteSalle(int salleId, LocalDate date, LocalTime heureDebut, LocalTime heureFin, int coursActuelId) {

        List<Cours> coursDeLaSalle = coursDAO.trouverParSalleId(salleId);


        List<Cours> coursMemeDate = coursDeLaSalle.stream()
                .filter(c -> c.getDate().equals(date) && c.getId() != coursActuelId)
                .collect(Collectors.toList());


        for (Cours autreCours : coursMemeDate) {

            if ((heureDebut.isAfter(autreCours.getHeureDebut()) && heureDebut.isBefore(autreCours.getHeureFin())) ||
                    (heureFin.isAfter(autreCours.getHeureDebut()) && heureFin.isBefore(autreCours.getHeureFin())) ||
                    (heureDebut.isBefore(autreCours.getHeureDebut()) && heureFin.isAfter(autreCours.getHeureFin())) ||
                    heureDebut.equals(autreCours.getHeureDebut()) || heureFin.equals(autreCours.getHeureFin())) {
                return false;
            }
        }

        return true;
    }

    @FXML
    private void handleModifierCours(ActionEvent event) {
        Cours coursSelectionne = coursTable.getSelectionModel().getSelectedItem();

        if (coursSelectionne == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un cours à modifier.");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/cours_form.fxml"));
            Parent root = loader.load();

            CoursFormController controller = loader.getController();
            controller.setCours(coursSelectionne);

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle("Modifier un cours");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();


            chargerDonnees();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement du formulaire.");
        }
    }



    @FXML
    private void handleExporterSemaine(ActionEvent event) {

        LocalDate date = datePicker.getValue();
        LocalDate debutSemaine = date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate finSemaine = debutSemaine.plusDays(6);


        List<Cours> coursSemaine;

        if (utilisateur instanceof Enseignant) {
            coursSemaine = coursDAO.trouverParEnseignantId(utilisateur.getId()).stream()
                    .filter(c -> !c.getDate().isBefore(debutSemaine) && !c.getDate().isAfter(finSemaine))
                    .collect(Collectors.toList());
        } else if (utilisateur instanceof Etudiant) {
            coursSemaine = coursDAO.trouverParEtudiantId(utilisateur.getId()).stream()
                    .filter(c -> !c.getDate().isBefore(debutSemaine) && !c.getDate().isAfter(finSemaine))
                    .collect(Collectors.toList());
        } else {

            coursSemaine = coursDAO.trouverParSemaine(debutSemaine, finSemaine);
        }

        if (coursSemaine.isEmpty()) {
            showAlert(Alert.AlertType.INFORMATION, "Information", "Aucun cours à exporter pour cette semaine.");
            return;
        }


        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Enregistrer l'emploi du temps");
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Fichiers PDF", "*.pdf"));
        fileChooser.setInitialFileName("emploi_du_temps_semaine_" +
                debutSemaine.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")) + ".pdf");

        File file = fileChooser.showSaveDialog(titleLabel.getScene().getWindow());

        if (file != null) {
            String utilisateurNom = utilisateur.getPrenom() + " " + utilisateur.getNom();
            boolean success = PDFExporter.exporterEmploiDuTempsSemaine(coursSemaine, debutSemaine, utilisateurNom, file.getAbsolutePath());

            if (success) {
                showAlert(Alert.AlertType.INFORMATION, "Succès", "L'emploi du temps a été exporté avec succès.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors de l'exportation de l'emploi du temps.");
            }
        }
    }

    private void effacerDetailsCours() {
        detailsContainer.setVisible(false);
    }

    @FXML
    private void handlePreviousDate(ActionEvent event) {
        LocalDate currentDate = datePicker.getValue();

        switch (currentView) {
            case "Jour":
                datePicker.setValue(currentDate.minusDays(1));
                break;
            case "Semaine":
                datePicker.setValue(currentDate.minusWeeks(1));
                break;
            case "Mois":
                datePicker.setValue(currentDate.minusMonths(1));
                break;
        }
    }

    @FXML
    private void handleNextDate(ActionEvent event) {
        LocalDate currentDate = datePicker.getValue();

        switch (currentView) {
            case "Jour":
                datePicker.setValue(currentDate.plusDays(1));
                break;
            case "Semaine":
                datePicker.setValue(currentDate.plusWeeks(1));
                break;
            case "Mois":
                datePicker.setValue(currentDate.plusMonths(1));
                break;
        }
    }

    @FXML
    private void handleToday(ActionEvent event) {
        datePicker.setValue(LocalDate.now());
    }

    @FXML
    private void handleDeconnexion(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) titleLabel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Connexion");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement de la page de connexion.");
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
