package ui;

import dao.CoursDAO;
import dao.NotificationDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Cours;
import model.Enseignant;
import model.Notification;
import model.Salle;

import java.io.IOException;
import java.net.URL;
import java.time.LocalTime;
import java.util.List;
import java.util.ResourceBundle;

public class EnseignantDashboardController implements Initializable {

    @FXML
    private Label welcomeLabel;

    @FXML
    private TabPane tabPane;


    @FXML
    private TableView<Cours> coursTable;

    @FXML
    private TableColumn<Cours, String> coursNomColumn;

    @FXML
    private TableColumn<Cours, String> coursTypeColumn;

    @FXML
    private TableColumn<Cours, Integer> coursDureeColumn;

    @FXML
    private TableColumn<Cours, LocalTime> coursHeureDebutColumn;

    @FXML
    private TableColumn<Cours, LocalTime> coursHeureFinColumn;

    @FXML
    private TableColumn<Cours, String> coursSalleColumn;


    @FXML
    private TextArea notificationTextArea;

    @FXML
    private Button envoyerNotificationButton;

    private Enseignant enseignant;
    private CoursDAO coursDAO = new CoursDAO();
    private NotificationDAO notificationDAO = new NotificationDAO();

    public void setEnseignant(Enseignant enseignant) {
        this.enseignant = enseignant;
        if (welcomeLabel != null) {
            welcomeLabel.setText("Bienvenue, " + enseignant.getPrenom() + " " + enseignant.getNom());
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {



        coursNomColumn.setCellValueFactory(new PropertyValueFactory<>("nom"));
        coursTypeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        coursDureeColumn.setCellValueFactory(new PropertyValueFactory<>("duree"));
        coursHeureDebutColumn.setCellValueFactory(new PropertyValueFactory<>("heureDebut"));
        coursHeureFinColumn.setCellValueFactory(new PropertyValueFactory<>("heureFin"));

        coursSalleColumn.setCellValueFactory(cellData -> {
            Salle salle = cellData.getValue().getSalle();
            return javafx.beans.binding.Bindings.createStringBinding(() ->
                    salle != null ? salle.getNumero() : "Non assignée");
        });
    }

    public void chargerDonnees() {
        try {
            if (enseignant != null) {

                List<Cours> cours = coursDAO.trouverParEnseignantId(enseignant.getId());
                ObservableList<Cours> coursList = FXCollections.observableArrayList(cours);
                coursTable.setItems(coursList);
            }
        } catch (Exception e) {
            System.err.println("Erreur lors du chargement des données: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleEnvoyerNotification(ActionEvent event) {
        String contenu = notificationTextArea.getText();

        if (contenu.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Champ vide", "Veuillez saisir le contenu de la notification.");
            return;
        }

        Notification notification = new Notification(0, contenu, "admin");
        boolean success = notificationDAO.ajouter(notification);

        if (success) {
            showAlert(Alert.AlertType.INFORMATION, "Succès", "La notification a été envoyée avec succès.");
            notificationTextArea.clear();
        } else {
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors de l'envoi de la notification.");
        }
    }

    @FXML
    private void handleVoirDetailsCours(ActionEvent event) {
        Cours coursSelectionne = coursTable.getSelectionModel().getSelectedItem();

        if (coursSelectionne == null) {
            showAlert(Alert.AlertType.WARNING, "Aucune sélection", "Veuillez sélectionner un cours pour voir les détails.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Détails du cours");
        alert.setHeaderText(coursSelectionne.getNom());
        alert.setContentText(coursSelectionne.getInfos());
        alert.showAndWait();
    }

    @FXML
    private void handleDeconnexion(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/login.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) welcomeLabel.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Connexion");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur", "Une erreur est survenue lors du chargement de la page de connexion.");
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

