package model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Cours {
    private int id;
    private String nom;
    private String type;
    private int duree;
    private LocalDate date;
    private LocalTime heureDebut;
    private LocalTime heureFin;
    private Salle salle;
    private Enseignant enseignant;
    private List<Etudiant> etudiants;

    public Cours(int id, String nom, String type, int duree, LocalDate date, LocalTime heureDebut, LocalTime heureFin) {
        this.id = id;
        this.nom = nom;
        this.type = type;
        this.duree = duree;
        this.date = date;
        this.heureDebut = heureDebut;
        this.heureFin = heureFin;
        this.etudiants = new ArrayList<>();
    }

    public Cours() {
        this.etudiants = new ArrayList<>();
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getDuree() {
        return duree;
    }

    public void setDuree(int duree) {
        this.duree = duree;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalTime getHeureDebut() {
        return heureDebut;
    }

    public void setHeureDebut(LocalTime heureDebut) {
        this.heureDebut = heureDebut;
    }

    public LocalTime getHeureFin() {
        return heureFin;
    }

    public void setHeureFin(LocalTime heureFin) {
        this.heureFin = heureFin;
    }

    public Salle getSalle() {
        return salle;
    }

    public void setSalle(Salle salle) {
        this.salle = salle;
    }

    public Enseignant getEnseignant() {
        return enseignant;
    }

    public void setEnseignant(Enseignant enseignant) {
        this.enseignant = enseignant;
    }

    public List<Etudiant> getEtudiants() {
        return etudiants;
    }

    public void setEtudiants(List<Etudiant> etudiants) {
        this.etudiants = etudiants;
    }

    public void ajouterEtudiant(Etudiant etudiant) {
        this.etudiants.add(etudiant);
    }

    public void supprimerEtudiant(Etudiant etudiant) {
        this.etudiants.remove(etudiant);
    }

    public String getInfos() {
        return "Cours: " + this.nom + " (" + this.type + ")\n" +
                "Date: " + this.date + "\n" +
                "Durée: " + this.duree + " minutes\n" +
                "Horaire: " + this.heureDebut + " - " + this.heureFin + "\n" +
                "Salle: " + (this.salle != null ? this.salle.getNumero() : "Non assignée") + "\n" +
                "Enseignant: " + (this.enseignant != null ? this.enseignant.getNom() + " " + this.enseignant.getPrenom() : "Non assigné");
    }
}
