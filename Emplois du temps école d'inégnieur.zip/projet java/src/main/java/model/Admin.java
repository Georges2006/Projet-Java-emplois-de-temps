package model;

public class Admin extends Utilisateur {
    
    public Admin(int id, String nom, String prenom, String email, String mdp) {
        super(id, nom, prenom, email, mdp);
    }
    
    public Admin() {
        super();
    }
    
    @Override
    public boolean connecter() {

        System.out.println("Connexion en tant qu'administrateur: " + this.nom);
        return true;
    }
    
    public boolean modifierEmplois() {

        System.out.println("Modification des emplois du temps par l'administrateur: " + this.nom);
        return true;
    }
    
    public boolean affecterEnseignant(Enseignant enseignant, Cours cours) {

        System.out.println("Affectation de l'enseignant " + enseignant.getNom() + " au cours " + cours.getNom());
        return true;
    }
    
    public boolean gererSalle(Salle salle) {

        System.out.println("Gestion de la salle " + salle.getNumero());
        return true;
    }
    
    public void suivreStat() {

        System.out.println("Suivi des statistiques par l'administrateur: " + this.nom);
    }
}
