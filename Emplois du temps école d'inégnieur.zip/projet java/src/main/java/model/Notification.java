package model;

public class Notification {
    private int id;
    private String contenu;
    private String destinataire;
    
    public Notification(int id, String contenu, String destinataire) {
        this.id = id;
        this.contenu = contenu;
        this.destinataire = destinataire;
    }
    
    public Notification() {

    }
    

    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getContenu() {
        return contenu;
    }
    
    public void setContenu(String contenu) {
        this.contenu = contenu;
    }
    
    public String getDestinataire() {
        return destinataire;
    }
    
    public void setDestinataire(String destinataire) {
        this.destinataire = destinataire;
    }
    
    public void envoyerNotif() {
        System.out.println("Notification envoyée à " + this.destinataire + ": " + this.contenu);
    }
}
