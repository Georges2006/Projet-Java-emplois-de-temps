package model;

public class Enseignant extends Utilisateur {
    
    public Enseignant(int id, String nom, String prenom, String email, String mdp) {
        super(id, nom, prenom, email, mdp);
    }
    
    public Enseignant() {
        super();
    }
    
    @Override
    public boolean connecter() {

        System.out.println("Connexion en tant qu'enseignant: " + this.nom);
        return true;
    }
    
    public void consulterEmplois() {

        System.out.println("Consultation des emplois du temps par l'enseignant: " + this.nom);
    }
    
    public void notifierAdmin() {

        System.out.println("Notification envoyée à l'administrateur par l'enseignant: " + this.nom);
    }
}
