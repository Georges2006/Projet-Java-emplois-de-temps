package model;

public class Etudiant extends Utilisateur {
    
    public Etudiant(int id, String nom, String prenom, String email, String mdp) {
        super(id, nom, prenom, email, mdp);
    }
    
    public Etudiant() {
        super();
    }
    
    @Override
    public boolean connecter() {

        System.out.println("Connexion en tant qu'étudiant: " + this.nom);
        return true;
    }
    
    public void consulterEmplois() {

        System.out.println("Consultation des emplois du temps par l'étudiant: " + this.nom);
    }
    
    public void voirSalleInfo() {

        System.out.println("Consultation des informations des salles par l'étudiant: " + this.nom);
    }
}
