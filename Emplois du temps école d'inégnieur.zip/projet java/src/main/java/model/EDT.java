package model;

import java.util.ArrayList;
import java.util.List;

public class EDT {
    private int id;
    private List<Cours> cours;
    
    public EDT(int id) {
        this.id = id;
        this.cours = new ArrayList<>();
    }
    
    public EDT() {
        this.cours = new ArrayList<>();
    }
    

    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public List<Cours> getCours() {
        return cours;
    }
    
    public void setCours(List<Cours> cours) {
        this.cours = cours;
    }
    
    public void afficherEmploi() {
        System.out.println("Emploi du temps ID: " + this.id);
        for (Cours c : cours) {
            System.out.println("- " + c.getNom() + " (" + c.getType() + ") - " 
                    + c.getHeureDebut() + " à " + c.getHeureFin());
        }
    }
    
    public void ajouterCours(Cours cours) {
        this.cours.add(cours);
    }
    
    public void supprimerCours(Cours cours) {
        this.cours.remove(cours);
    }
}
