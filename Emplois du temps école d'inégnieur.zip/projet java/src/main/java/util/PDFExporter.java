package util;

import model.Cours;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.IOException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class PDFExporter {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm");


    public static boolean exporterEmploiDuTempsSemaine(List<Cours> cours, LocalDate dateDebut, String utilisateurNom, String cheminFichier) {
        PDDocument document = null;

        try {
            document = new PDDocument();


            float margin = 50;
            float yStart = 750;
            float yPosition = yStart;
            float lineHeight = 15;


            Map<DayOfWeek, List<Cours>> coursParJour = new TreeMap<>();
            for (DayOfWeek day : DayOfWeek.values()) {
                final DayOfWeek currentDay = day;
                List<Cours> coursJour = cours.stream()
                        .filter(c -> c.getDate() != null && c.getDate().getDayOfWeek() == currentDay)
                        .sorted((c1, c2) -> c1.getHeureDebut().compareTo(c2.getHeureDebut()))
                        .collect(Collectors.toList());
                coursParJour.put(day, coursJour);
            }


            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);


            PDPageContentStream contentStream = new PDPageContentStream(document, page);


            LocalDate dateFin = dateDebut.plusDays(6);
            String titre = "Emploi du temps - Semaine du " + dateDebut.format(DATE_FORMATTER) +
                    " au " + dateFin.format(DATE_FORMATTER);

            contentStream.beginText();
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 16);
            contentStream.newLineAtOffset(margin, yPosition);
            contentStream.showText(titre);
            contentStream.endText();

            yPosition -= 20;


            contentStream.beginText();
            contentStream.setFont(PDType1Font.HELVETICA, 12);
            contentStream.newLineAtOffset(margin, yPosition);
            contentStream.showText("Utilisateur: " + utilisateurNom);
            contentStream.endText();

            yPosition -= 30;


            for (DayOfWeek jour : DayOfWeek.values()) {

                if (yPosition < 100) {

                    contentStream.close();


                    page = new PDPage(PDRectangle.A4);
                    document.addPage(page);


                    contentStream = new PDPageContentStream(document, page);
                    yPosition = yStart;
                }


                String nomJour = jour.getDisplayName(TextStyle.FULL, Locale.FRANCE);
                LocalDate dateJour = dateDebut.plusDays(jour.getValue() - 1);

                contentStream.beginText();
                contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
                contentStream.newLineAtOffset(margin, yPosition);
                contentStream.showText(nomJour + " - " + dateJour.format(DATE_FORMATTER));
                contentStream.endText();

                yPosition -= 20;


                List<Cours> coursJour = coursParJour.get(jour);

                if (coursJour.isEmpty()) {
                    contentStream.beginText();
                    contentStream.setFont(PDType1Font.HELVETICA_OBLIQUE, 10);
                    contentStream.newLineAtOffset(margin, yPosition);
                    contentStream.showText("Aucun cours");
                    contentStream.endText();
                    yPosition -= lineHeight;
                } else {
                    for (Cours c : coursJour) {

                        if (yPosition < 100) {

                            contentStream.close();


                            page = new PDPage(PDRectangle.A4);
                            document.addPage(page);


                            contentStream = new PDPageContentStream(document, page);
                            yPosition = yStart;


                            contentStream.beginText();
                            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
                            contentStream.newLineAtOffset(margin, yPosition);
                            contentStream.showText(nomJour + " - " + dateJour.format(DATE_FORMATTER) + " (suite)");
                            contentStream.endText();

                            yPosition -= 20;
                        }

                        contentStream.beginText();
                        contentStream.setFont(PDType1Font.HELVETICA, 10);
                        contentStream.newLineAtOffset(margin, yPosition);


                        String horaire = c.getHeureDebut().format(TIME_FORMATTER) + " - " + c.getHeureFin().format(TIME_FORMATTER);
                        String enseignantInfo = c.getEnseignant() != null ?
                                c.getEnseignant().getNom() + " " + c.getEnseignant().getPrenom() : "Non assigné";
                        String salleInfo = c.getSalle() != null ? c.getSalle().getNumero() : "Non assignée";

                        contentStream.showText(horaire + " - " + c.getNom() + " (" + c.getType() + ")");
                        contentStream.endText();

                        yPosition -= lineHeight;


                        contentStream.beginText();
                        contentStream.setFont(PDType1Font.HELVETICA, 9);
                        contentStream.newLineAtOffset(margin + 15, yPosition);
                        contentStream.showText("Salle: " + salleInfo + " - Enseignant: " + enseignantInfo);
                        contentStream.endText();

                        yPosition -= lineHeight + 5;
                    }
                }


                yPosition -= 10;
            }


            contentStream.beginText();
            contentStream.setFont(PDType1Font.HELVETICA_OBLIQUE, 8);
            contentStream.newLineAtOffset(margin, 50);
            contentStream.showText("Document généré le " + LocalDate.now().format(DATE_FORMATTER));
            contentStream.endText();


            contentStream.close();


            document.save(cheminFichier);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        } finally {

            if (document != null) {
                try {
                    document.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
