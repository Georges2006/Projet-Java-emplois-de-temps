package dao;

import model.Cours;
import model.Enseignant;
import model.Etudiant;
import model.Salle;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class CoursDAO {

    public boolean ajouter(Cours cours) {
        String sql = "INSERT INTO cours (nom, type, duree, date, heure_debut, heure_fin, salle_id, enseignant_id, edt_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, cours.getNom());
            pstmt.setString(2, cours.getType());
            pstmt.setInt(3, cours.getDuree());
            pstmt.setString(4, cours.getDate().toString());
            pstmt.setString(5, cours.getHeureDebut().toString());
            pstmt.setString(6, cours.getHeureFin().toString());

            if (cours.getSalle() != null) {
                pstmt.setInt(7, cours.getSalle().getId());
            } else {
                pstmt.setNull(7, Types.INTEGER);
            }

            if (cours.getEnseignant() != null) {
                pstmt.setInt(8, cours.getEnseignant().getId());
            } else {
                pstmt.setNull(8, Types.INTEGER);
            }


            pstmt.setInt(9, 1);

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        cours.setId(generatedKeys.getInt(1));


                        if (cours.getEtudiants() != null && !cours.getEtudiants().isEmpty()) {
                            ajouterEtudiantsCours(cours.getId(), cours.getEtudiants());
                        }

                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'ajout du cours: " + e.getMessage());
        }

        return false;
    }

    private void ajouterEtudiantsCours(int coursId, List<Etudiant> etudiants) {
        String sql = "INSERT INTO cours_etudiant (cours_id, etudiant_id) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            for (Etudiant etudiant : etudiants) {
                pstmt.setInt(1, coursId);
                pstmt.setInt(2, etudiant.getId());
                pstmt.addBatch();
            }

            pstmt.executeBatch();
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'ajout des étudiants au cours: " + e.getMessage());
        }
    }

    public Cours trouverParId(int id) {
        String sql = "SELECT c.*, s.id as salle_id, s.numero, s.capacite, s.equipement, " +
                "u.id as enseignant_id, u.nom as enseignant_nom, u.prenom as enseignant_prenom, " +
                "u.email as enseignant_email, u.mdp as enseignant_mdp " +
                "FROM cours c " +
                "LEFT JOIN salle s ON c.salle_id = s.id " +
                "LEFT JOIN utilisateur u ON c.enseignant_id = u.id " +
                "WHERE c.id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                Cours cours = creerCours(rs);
                cours.setEtudiants(trouverEtudiantsParCoursId(id));
                return cours;
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche du cours: " + e.getMessage());
        }

        return null;
    }

    private List<Etudiant> trouverEtudiantsParCoursId(int coursId) {
        List<Etudiant> etudiants = new ArrayList<>();
        String sql = "SELECT u.* FROM utilisateur u " +
                "JOIN cours_etudiant ce ON u.id = ce.etudiant_id " +
                "WHERE ce.cours_id = ? AND u.type = 'etudiant'";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, coursId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String nom = rs.getString("nom");
                String prenom = rs.getString("prenom");
                String email = rs.getString("email");
                String mdp = rs.getString("mdp");

                etudiants.add(new Etudiant(id, nom, prenom, email, mdp));
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des étudiants du cours: " + e.getMessage());
        }

        return etudiants;
    }

    public List<Cours> trouverTous() {
        List<Cours> cours = new ArrayList<>();
        String sql = "SELECT c.*, s.id as salle_id, s.numero, s.capacite, s.equipement, " +
                "u.id as enseignant_id, u.nom as enseignant_nom, u.prenom as enseignant_prenom, " +
                "u.email as enseignant_email, u.mdp as enseignant_mdp " +
                "FROM cours c " +
                "LEFT JOIN salle s ON c.salle_id = s.id " +
                "LEFT JOIN utilisateur u ON c.enseignant_id = u.id";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Cours c = creerCours(rs);
                c.setEtudiants(trouverEtudiantsParCoursId(c.getId()));
                cours.add(c);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération des cours: " + e.getMessage());
        }

        return cours;
    }

    public List<Cours> trouverParDate(LocalDate date) {
        List<Cours> cours = new ArrayList<>();
        String sql = "SELECT c.*, s.id as salle_id, s.numero, s.capacite, s.equipement, " +
                "u.id as enseignant_id, u.nom as enseignant_nom, u.prenom as enseignant_prenom, " +
                "u.email as enseignant_email, u.mdp as enseignant_mdp " +
                "FROM cours c " +
                "LEFT JOIN salle s ON c.salle_id = s.id " +
                "LEFT JOIN utilisateur u ON c.enseignant_id = u.id " +
                "WHERE c.date = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, date.toString());
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Cours c = creerCours(rs);
                c.setEtudiants(trouverEtudiantsParCoursId(c.getId()));
                cours.add(c);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des cours par date: " + e.getMessage());
        }

        return cours;
    }

    public List<Cours> trouverParSemaine(LocalDate debutSemaine, LocalDate finSemaine) {
        List<Cours> cours = new ArrayList<>();
        String sql = "SELECT c.*, s.id as salle_id, s.numero, s.capacite, s.equipement, " +
                "u.id as enseignant_id, u.nom as enseignant_nom, u.prenom as enseignant_prenom, " +
                "u.email as enseignant_email, u.mdp as enseignant_mdp " +
                "FROM cours c " +
                "LEFT JOIN salle s ON c.salle_id = s.id " +
                "LEFT JOIN utilisateur u ON c.enseignant_id = u.id " +
                "WHERE c.date BETWEEN ? AND ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, debutSemaine.toString());
            pstmt.setString(2, finSemaine.toString());
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Cours c = creerCours(rs);
                c.setEtudiants(trouverEtudiantsParCoursId(c.getId()));
                cours.add(c);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des cours par semaine: " + e.getMessage());
        }

        return cours;
    }

    public List<Cours> trouverParMois(int mois, int annee) {
        List<Cours> cours = new ArrayList<>();
        String sql = "SELECT c.*, s.id as salle_id, s.numero, s.capacite, s.equipement, " +
                "u.id as enseignant_id, u.nom as enseignant_nom, u.prenom as enseignant_prenom, " +
                "u.email as enseignant_email, u.mdp as enseignant_mdp " +
                "FROM cours c " +
                "LEFT JOIN salle s ON c.salle_id = s.id " +
                "LEFT JOIN utilisateur u ON c.enseignant_id = u.id " +
                "WHERE strftime('%m', c.date) = ? AND strftime('%Y', c.date) = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, String.format("%02d", mois));
            pstmt.setString(2, String.valueOf(annee));
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Cours c = creerCours(rs);
                c.setEtudiants(trouverEtudiantsParCoursId(c.getId()));
                cours.add(c);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des cours par mois: " + e.getMessage());
        }

        return cours;
    }

    public List<Cours> trouverParEnseignantId(int enseignantId) {
        List<Cours> cours = new ArrayList<>();
        String sql = "SELECT c.*, s.id as salle_id, s.numero, s.capacite, s.equipement, " +
                "u.id as enseignant_id, u.nom as enseignant_nom, u.prenom as enseignant_prenom, " +
                "u.email as enseignant_email, u.mdp as enseignant_mdp " +
                "FROM cours c " +
                "LEFT JOIN salle s ON c.salle_id = s.id " +
                "LEFT JOIN utilisateur u ON c.enseignant_id = u.id " +
                "WHERE c.enseignant_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, enseignantId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Cours c = creerCours(rs);
                c.setEtudiants(trouverEtudiantsParCoursId(c.getId()));
                cours.add(c);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des cours par enseignant: " + e.getMessage());
        }

        return cours;
    }

    public List<Cours> trouverParEtudiantId(int etudiantId) {
        List<Cours> cours = new ArrayList<>();
        String sql = "SELECT c.*, s.id as salle_id, s.numero, s.capacite, s.equipement, " +
                "u.id as enseignant_id, u.nom as enseignant_nom, u.prenom as enseignant_prenom, " +
                "u.email as enseignant_email, u.mdp as enseignant_mdp " +
                "FROM cours c " +
                "LEFT JOIN salle s ON c.salle_id = s.id " +
                "LEFT JOIN utilisateur u ON c.enseignant_id = u.id " +
                "JOIN cours_etudiant ce ON c.id = ce.cours_id " +
                "WHERE ce.etudiant_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, etudiantId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Cours c = creerCours(rs);
                c.setEtudiants(trouverEtudiantsParCoursId(c.getId()));
                cours.add(c);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des cours par étudiant: " + e.getMessage());
        }

        return cours;
    }

    public List<Cours> trouverParSalleId(int salleId) {
        List<Cours> cours = new ArrayList<>();
        String sql = "SELECT c.*, s.id as salle_id, s.numero, s.capacite, s.equipement, " +
                "u.id as enseignant_id, u.nom as enseignant_nom, u.prenom as enseignant_prenom, " +
                "u.email as enseignant_email, u.mdp as enseignant_mdp " +
                "FROM cours c " +
                "LEFT JOIN salle s ON c.salle_id = s.id " +
                "LEFT JOIN utilisateur u ON c.enseignant_id = u.id " +
                "WHERE c.salle_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, salleId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Cours c = creerCours(rs);
                c.setEtudiants(trouverEtudiantsParCoursId(c.getId()));
                cours.add(c);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des cours par salle: " + e.getMessage());
        }

        return cours;
    }

    public boolean modifier(Cours cours) {
        String sql = "UPDATE cours SET nom = ?, type = ?, duree = ?, date = ?, heure_debut = ?, heure_fin = ?, " +
                "salle_id = ?, enseignant_id = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, cours.getNom());
            pstmt.setString(2, cours.getType());
            pstmt.setInt(3, cours.getDuree());
            pstmt.setString(4, cours.getDate().toString());
            pstmt.setString(5, cours.getHeureDebut().toString());
            pstmt.setString(6, cours.getHeureFin().toString());

            if (cours.getSalle() != null) {
                pstmt.setInt(7, cours.getSalle().getId());
            } else {
                pstmt.setNull(7, Types.INTEGER);
            }

            if (cours.getEnseignant() != null) {
                pstmt.setInt(8, cours.getEnseignant().getId());
            } else {
                pstmt.setNull(8, Types.INTEGER);
            }

            pstmt.setInt(9, cours.getId());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {

                supprimerEtudiantsCours(cours.getId());
                if (cours.getEtudiants() != null && !cours.getEtudiants().isEmpty()) {
                    ajouterEtudiantsCours(cours.getId(), cours.getEtudiants());
                }

                return true;
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la modification du cours: " + e.getMessage());
        }

        return false;
    }

    private void supprimerEtudiantsCours(int coursId) {
        String sql = "DELETE FROM cours_etudiant WHERE cours_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, coursId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression des étudiants du cours: " + e.getMessage());
        }
    }

    public boolean supprimer(int id) {

        supprimerEtudiantsCours(id);

        String sql = "DELETE FROM cours WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression du cours: " + e.getMessage());
        }

        return false;
    }

    private Cours creerCours(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        String nom = rs.getString("nom");
        String type = rs.getString("type");
        int duree = rs.getInt("duree");


        LocalDate date;
        try {
            String dateStr = rs.getString("date");
            date = (dateStr != null) ? LocalDate.parse(dateStr) : LocalDate.now();
        } catch (SQLException e) {

            date = LocalDate.now();
            System.out.println("Utilisation de la date du jour pour le cours " + nom + " (ID: " + id + ")");
        }

        LocalTime heureDebut = LocalTime.parse(rs.getString("heure_debut"));
        LocalTime heureFin = LocalTime.parse(rs.getString("heure_fin"));

        Cours cours = new Cours(id, nom, type, duree, date, heureDebut, heureFin);


        if (rs.getObject("salle_id") != null) {
            int salleId = rs.getInt("salle_id");
            String numero = rs.getString("numero");
            int capacite = rs.getInt("capacite");
            String equipement = rs.getString("equipement");

            cours.setSalle(new Salle(salleId, numero, capacite, equipement));
        }


        if (rs.getObject("enseignant_id") != null) {
            int enseignantId = rs.getInt("enseignant_id");
            String enseignantNom = rs.getString("enseignant_nom");
            String enseignantPrenom = rs.getString("enseignant_prenom");
            String enseignantEmail = rs.getString("enseignant_email");
            String enseignantMdp = rs.getString("enseignant_mdp");

            cours.setEnseignant(new Enseignant(enseignantId, enseignantNom, enseignantPrenom, enseignantEmail, enseignantMdp));
        }

        return cours;
    }

}
