package dao;

import model.Admin;
import model.Enseignant;
import model.Etudiant;
import model.Salle;

public class DatabaseInitializer {

    private static final UtilisateurDAO utilisateurDAO = new UtilisateurDAO();
    private static final SalleDAO salleDAO = new SalleDAO();

    public static void initialize() {
        try {
            createDefaultAdmin();
            createSampleData();
        } catch (Exception e) {
            System.err.println("Erreur lors de l'initialisation des données: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void createDefaultAdmin() {

        int adminCount = utilisateurDAO.compterAdmins();

        if (adminCount == 0) {

            Admin admin = new Admin();
            admin.setNom("Admin");
            admin.setPrenom("System");
            admin.setEmail("admin@example.com");
            admin.setMdp("admin123");

            if (utilisateurDAO.ajouter(admin)) {
                System.out.println("Administrateur par défaut créé avec succès.");
                System.out.println("Email: admin@example.com");
                System.out.println("Mot de passe: admin123");
            } else {
                System.err.println("Erreur lors de la création de l'administrateur par défaut.");
            }
        }
    }

    private static void createSampleData() {

        int userCount = utilisateurDAO.compterUtilisateurs();

        if (userCount <= 1) {
            try {

                Enseignant enseignant1 = new Enseignant();
                enseignant1.setNom("Dupont");
                enseignant1.setPrenom("Jean");
                enseignant1.setEmail("jean.dupont@example.com");
                enseignant1.setMdp("password");
                utilisateurDAO.ajouter(enseignant1);

                Enseignant enseignant2 = new Enseignant();
                enseignant2.setNom("Martin");
                enseignant2.setPrenom("Sophie");
                enseignant2.setEmail("sophie.martin@example.com");
                enseignant2.setMdp("password");
                utilisateurDAO.ajouter(enseignant2);


                Etudiant etudiant1 = new Etudiant();
                etudiant1.setNom("Lefebvre");
                etudiant1.setPrenom("Thomas");
                etudiant1.setEmail("thomas.lefebvre@example.com");
                etudiant1.setMdp("password");
                utilisateurDAO.ajouter(etudiant1);

                Etudiant etudiant2 = new Etudiant();
                etudiant2.setNom("Dubois");
                etudiant2.setPrenom("Marie");
                etudiant2.setEmail("marie.dubois@example.com");
                etudiant2.setMdp("password");
                utilisateurDAO.ajouter(etudiant2);

                Etudiant etudiant3 = new Etudiant();
                etudiant3.setNom("Petit");
                etudiant3.setPrenom("Lucas");
                etudiant3.setEmail("lucas.petit@example.com");
                etudiant3.setMdp("password");
                utilisateurDAO.ajouter(etudiant3);


                Salle salle1 = new Salle();
                salle1.setNumero("A101");
                salle1.setCapacite(30);
                salle1.setEquipement("Projecteur, Tableau blanc");
                salleDAO.ajouter(salle1);

                Salle salle2 = new Salle();
                salle2.setNumero("B202");
                salle2.setCapacite(50);
                salle2.setEquipement("Projecteur, Tableau blanc, Ordinateurs");
                salleDAO.ajouter(salle2);

                Salle salle3 = new Salle();
                salle3.setNumero("C303");
                salle3.setCapacite(20);
                salle3.setEquipement("Tableau blanc");
                salleDAO.ajouter(salle3);

                System.out.println("Données d'exemple créées avec succès.");
            } catch (Exception e) {
                System.err.println("Erreur lors de la création des données d'exemple: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}
