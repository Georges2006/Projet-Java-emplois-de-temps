package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

public class DatabaseConnection {
    private static final String DB_URL = "jdbc:sqlite:emploidutemps.db";
    private static boolean databaseInitialized = false;


    public static Connection getConnection() throws SQLException {
        Connection connection = DriverManager.getConnection(DB_URL);


        if (!databaseInitialized) {
            initializeDatabase(connection);
            databaseInitialized = true;
        }

        return connection;
    }

    private static void initializeDatabase(Connection connection) {
        try (Statement stmt = connection.createStatement()) {



            stmt.execute("CREATE TABLE IF NOT EXISTS utilisateur (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "nom TEXT NOT NULL," +
                    "prenom TEXT NOT NULL," +
                    "email TEXT UNIQUE NOT NULL," +
                    "mdp TEXT NOT NULL," +
                    "type TEXT NOT NULL" +
                    ")");


            stmt.execute("CREATE TABLE IF NOT EXISTS edt (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT" +
                    ")");


            boolean tableCoursExists = false;
            try (ResultSet rs = stmt.executeQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='cours'")) {
                tableCoursExists = rs.next();
            }

            if (tableCoursExists) {

                boolean dateColumnExists = false;
                try (ResultSet rs = stmt.executeQuery("PRAGMA table_info(cours)")) {
                    while (rs.next()) {
                        if ("date".equals(rs.getString("name"))) {
                            dateColumnExists = true;
                            break;
                        }
                    }
                }


                if (!dateColumnExists) {

                    stmt.execute("ALTER TABLE cours ADD COLUMN date TEXT DEFAULT '" + LocalDate.now() + "'");
                    System.out.println("Colonne 'date' ajoutée à la table 'cours'");
                }
            } else {

                stmt.execute("CREATE TABLE IF NOT EXISTS cours (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                        "nom TEXT NOT NULL," +
                        "type TEXT NOT NULL," +
                        "duree INTEGER NOT NULL," +
                        "date TEXT NOT NULL," +
                        "heure_debut TEXT NOT NULL," +
                        "heure_fin TEXT NOT NULL," +
                        "salle_id INTEGER," +
                        "enseignant_id INTEGER," +
                        "edt_id INTEGER," +
                        "FOREIGN KEY (salle_id) REFERENCES salle(id)," +
                        "FOREIGN KEY (enseignant_id) REFERENCES utilisateur(id)," +
                        "FOREIGN KEY (edt_id) REFERENCES edt(id)" +
                        ")");
            }


            stmt.execute("CREATE TABLE IF NOT EXISTS salle (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "numero TEXT UNIQUE NOT NULL," +
                    "capacite INTEGER NOT NULL," +
                    "equipement TEXT" +
                    ")");


            stmt.execute("CREATE TABLE IF NOT EXISTS notification (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "contenu TEXT NOT NULL," +
                    "destinataire TEXT NOT NULL," +
                    "date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                    ")");


            stmt.execute("CREATE TABLE IF NOT EXISTS cours_etudiant (" +
                    "cours_id INTEGER," +
                    "etudiant_id INTEGER," +
                    "PRIMARY KEY (cours_id, etudiant_id)," +
                    "FOREIGN KEY (cours_id) REFERENCES cours(id)," +
                    "FOREIGN KEY (etudiant_id) REFERENCES utilisateur(id)" +
                    ")");

            System.out.println("Tables créées ou mises à jour avec succès.");
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'initialisation de la base de données: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
