package dao;

import model.Notification;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NotificationDAO {
    
    public boolean ajouter(Notification notification) {
        String sql = "INSERT INTO notification (contenu, destinataire) VALUES (?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, notification.getContenu());
            pstmt.setString(2, notification.getDestinataire());
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        notification.setId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'ajout de la notification: " + e.getMessage());
        }
        
        return false;
    }
    
    public Notification trouverParId(int id) {
        String sql = "SELECT * FROM notification WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return creerNotification(rs);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche de la notification: " + e.getMessage());
        }
        
        return null;
    }
    
    public List<Notification> trouverParDestinataire(String destinataire) {
        List<Notification> notifications = new ArrayList<>();
        String sql = "SELECT * FROM notification WHERE destinataire = ? ORDER BY date_creation DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, destinataire);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                notifications.add(creerNotification(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche des notifications: " + e.getMessage());
        }
        
        return notifications;
    }
    
    public List<Notification> trouverTous() {
        List<Notification> notifications = new ArrayList<>();
        String sql = "SELECT * FROM notification ORDER BY date_creation DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                notifications.add(creerNotification(rs));
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération des notifications: " + e.getMessage());
        }
        
        return notifications;
    }
    
    public boolean supprimer(int id) {
        String sql = "DELETE FROM notification WHERE id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression de la notification: " + e.getMessage());
        }
        
        return false;
    }
    
    private Notification creerNotification(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        String contenu = rs.getString("contenu");
        String destinataire = rs.getString("destinataire");
        
        return new Notification(id, contenu, destinataire);
    }
}
